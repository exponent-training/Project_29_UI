import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/model/user.model';
import { RegisterService } from 'src/app/services/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  constructor(private registerService : RegisterService ){
  }
  
  
  //id:0 | undefined;
user = new User();
user1 = new User();
id : number | undefined;


  registerData(){
      //console.log(this.id + '  ' + this.name + ' ' + this.address+ '  ' + this.uname + '   ' + this.pass);
      console.log("Check Data : " + this.user);
      this.registerService.saveUser(this.user);
  }

  getData(id:any){
     console.log('============ ' + id);
      this.registerService.getData(id).subscribe(rs=>{
        this.user1 = rs;
        console.log('Data: ' + this.user1);
      });
  }

  updateData() {
    console.log('check updated User : '+ this.user1.name);
    this.registerService.updateUser(this.user1);
  }
}

 


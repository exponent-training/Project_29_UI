import { Injectable } from '@angular/core';
import { User } from '../model/user.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  url = 'http://localhost:9000';

  user1 = new User();

  constructor(private _http : HttpClient) { }

    saveUser(user : User){
       console.log("==== : " + user.id);
       //this._http.post<User>('http://localhost:9000/save', user);
       this._http.post(this.url+`/save`, user).subscribe();
    }
 
   public  getData(id:any): Observable<User>{
      return this._http.get<User>(this.url + '/get/' + id);
    }

    updateUser(user : User){
       this._http.put<User>(this.url+'/update',user).subscribe();;
    }
}

export class User {

    id: number | undefined ;
    name: string = '';
    address: string = '';
    uname: string = '';
    pass: string = '';
    
}